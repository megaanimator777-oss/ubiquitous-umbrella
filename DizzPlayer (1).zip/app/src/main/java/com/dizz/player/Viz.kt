package com.dizz.player

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

val STYLES = listOf("Столбики", "Круг", "Волна", "Точки")
val PALETTES = listOf("Неон", "Огонь", "Океан", "Лёд", "Радуга")

private val PAL = listOf(
    listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF), Color(0xFFFF2BD6)),
    listOf(Color(0xFFFFEA00), Color(0xFFFF6D00), Color(0xFFFF1744)),
    listOf(Color(0xFF69F0AE), Color(0xFF00B0FF), Color(0xFF304FFE)),
    listOf(Color(0xFFFFFFFF), Color(0xFF80D8FF), Color(0xFF448AFF))
)

fun pal(f: Float, t: Float): Color {
    val x = f.coerceIn(0f, 1f)
    if (Cfg.palette >= PAL.size) return Color.hsv((((x * 300f + t * 30f) % 360f) + 360f) % 360f, 0.8f, 1f)
    val c = PAL[Cfg.palette]
    val s = x * (c.size - 1)
    val i = s.toInt().coerceAtMost(c.size - 2)
    return lerp(c[i], c[i + 1], s - i)
}

private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val f: Float, val r: Float)

private val ps = ArrayList<P>()
private var seen = 0

private fun DrawScope.glow(p: Path, b: Brush, w: Float, al: Float = 1f) {
    for ((k, aa) in listOf(6f to 0.08f, 3f to 0.2f, 1f to 1f)) {
        drawPath(p, b, alpha = aa * al, style = Stroke(w * k, cap = StrokeCap.Round, join = StrokeJoin.Round), blendMode = BlendMode.Plus)
    }
}

private fun DrawScope.drawParticles(t: Float) {
    val w = size.width; val h = size.height
    if (seen != Engine.beatCount) {
        seen = Engine.beatCount
        repeat(14) {
            ps.add(P(w * Random.nextFloat(), h * (0.35f + 0.3f * Random.nextFloat()), (Random.nextFloat() - 0.5f) * 3f,
                -(1f + Random.nextFloat() * 3f), 1f, Random.nextFloat(), 3f + Random.nextFloat() * 5f))
        }
    }
    if (ps.size > 300) ps.subList(0, ps.size - 300).clear()
    val iter = ps.iterator()
    while (iter.hasNext()) {
        val p = iter.next()
        p.x += p.vx; p.y += p.vy; p.life -= 0.012f
        if (p.life <= 0f) iter.remove()
        else drawCircle(pal(p.f, t).copy(alpha = p.life * 0.8f), p.r * (0.4f + p.life), Offset(p.x, p.y), blendMode = BlendMode.Plus)
    }
}

fun DrawScope.drawViz(t: Float) {
    val w = size.width; val h = size.height
    val a = Engine.shown; val n = a.size; val pulse = Engine.pulse

    drawRect(Color(0xFF07070D))
    val rad = max(w, h) * 0.7f
    drawCircle(
        Brush.radialGradient(listOf(pal(0.5f, t).copy(alpha = 0.10f + 0.22f * pulse), Color.Transparent), center = center, radius = rad),
        radius = rad, center = center
    )

    when (Cfg.style % STYLES.size) {
        0 -> { // неоновые столбики с отражением
            val gap = w / n; val bw = gap * 0.55f
            val base = h * 0.58f; val maxH = h * 0.40f
            for (i in 0 until n) {
                val x = gap * (i + 0.5f)
                val bh = (maxH * a[i]).coerceAtLeast(bw)
                val c = pal(i / n.toFloat(), t)
                drawLine(c.copy(alpha = 0.18f), Offset(x, base), Offset(x, base - bh), bw * 2.4f, StrokeCap.Round, blendMode = BlendMode.Plus)
                drawLine(c, Offset(x, base), Offset(x, base - bh), bw, StrokeCap.Round, blendMode = BlendMode.Plus)
                drawLine(c.copy(alpha = 0.22f), Offset(x, base + bw * 1.5f), Offset(x, base + bw * 1.5f + bh * 0.45f), bw, StrokeCap.Round)
            }
        }
        1 -> { // кольцо со всплесками
            val r0 = min(w, h) * 0.20f * (1f + 0.10f * pulse)
            val m = n * 2; val rot = t * 0.15f; val len = min(w, h) * 0.30f
            for (i in 0 until m) {
                val k = if (i < n) i else m - 1 - i
                val ang = rot + i * (2f * PI.toFloat() / m)
                val d = Offset(cos(ang), sin(ang))
                val l = len * a[k] + 4f
                val col = pal(i.toFloat() / m, t)
                val s = center + d * r0; val e = center + d * (r0 + l)
                drawLine(col.copy(alpha = 0.2f), s, e, 9f, StrokeCap.Round, blendMode = BlendMode.Plus)
                drawLine(col, s, e, 4f, StrokeCap.Round, blendMode = BlendMode.Plus)
            }
            drawCircle(pal(0.5f, t).copy(alpha = 0.5f), r0, center, style = Stroke(3f), blendMode = BlendMode.Plus)
            drawCircle(pal(0.5f, t).copy(alpha = 0.10f + 0.2f * pulse), r0 * 0.96f, center, blendMode = BlendMode.Plus)
        }
        2 -> { // зеркальная неоновая волна (бас в центре)
            val cy = h * 0.5f; val amp = h * 0.34f; val m = n * 2
            val up = Path(); val dn = Path()
            var pu = 0f; var pd = 0f; var px = 0f
            for (i in 0 until m) {
                val k = if (i < n) n - 1 - i else i - n
                val x = w * i / (m - 1f)
                val v = a[k] * amp
                val yu = cy - v; val yd = cy + v
                if (i == 0) { up.moveTo(x, yu); dn.moveTo(x, yd) }
                else { val mx = (px + x) / 2f; up.quadraticBezierTo(px, pu, mx, (pu + yu) / 2f); dn.quadraticBezierTo(px, pd, mx, (pd + yd) / 2f) }
                px = x; pu = yu; pd = yd
            }
            val br = Brush.horizontalGradient(listOf(pal(0f, t), pal(0.5f, t), pal(1f, t)))
            glow(up, br, 4f); glow(dn, br, 4f, 0.6f)
            drawLine(Color.White.copy(alpha = 0.15f), Offset(0f, cy), Offset(w, cy), 2f)
        }
        else -> { // пунктирная зеркальная линия
            val cy = h * 0.5f; val m = 80; val half = m / 2
            for (i in 0 until m) {
                val k = ((if (i < half) half - 1 - i else i - half) * n / half).coerceIn(0, n - 1)
                val x = w * (i + 0.5f) / m
                val v = a[k]
                val d = h * 0.34f * v + 6f
                val c = pal(i / m.toFloat(), t)
                val r = 3.5f + 3f * v
                for (sg in floatArrayOf(-1f, 1f)) {
                    val o = Offset(x, cy + sg * d)
                    drawCircle(c.copy(alpha = 0.12f), r * 3.2f, o, blendMode = BlendMode.Plus)
                    drawCircle(c.copy(alpha = 0.35f), r * 1.8f, o, blendMode = BlendMode.Plus)
                    drawCircle(c, r, o, blendMode = BlendMode.Plus)
                }
            }
        }
    }
    if (Cfg.particles) drawParticles(t)
}
