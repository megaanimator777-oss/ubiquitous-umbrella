@file:OptIn(ExperimentalMaterial3Api::class)

package com.dizz.player

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0B0B12)
private val Acc = Color(0xFF9B5CFF)

class MainActivity : ComponentActivity() {
    private var ctrl: ListenableFuture<MediaController>? = null
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        App.refresh(this)
        Engine.attach(Audio.player.audioSessionId)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this); Audio.init(this); Flash.init(this)
        // подключение к сервису: он держит воспроизведение в фоне и показывает уведомление
        ctrl = MediaController.Builder(this, SessionToken(this, ComponentName(this, PlaybackService::class.java))).buildAsync()
        val need = ArrayList<String>()
        need.add(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE)
        need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        perms.launch(need.toTypedArray())
        setContent { DizzApp() }
    }

    override fun onStop() { Cfg.save(); super.onStop() }
    override fun onDestroy() { ctrl?.let { MediaController.releaseFuture(it) }; super.onDestroy() }
}

@Composable
fun DizzApp() {
    var screen by remember { mutableStateOf("lib") }
    BackHandler(screen != "lib") {
        screen = when (screen) { "edit" -> "lyrics"; "lyrics" -> "player"; else -> "lib" }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Acc, background = Bg, surface = Bg)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                "lib" -> LibraryScreen { screen = it }
                "player" -> PlayerScreen { screen = it }
                "lyrics" -> LyricsScreen { screen = it }
                "edit" -> EditScreen { screen = it }
                else -> SettingsScreen { screen = it }
            }
        }
    }
}

// ---------- общие мелочи ----------

@Composable
fun Chips(items: List<String>, sel: Int, on: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, s -> FilterChip(selected = i == sel, onClick = { on(i) }, label = { Text(s) }) }
    }
}

@Composable
fun Lt(s: String, size: Int, a: Float, bold: Boolean = false) {
    Text(
        s, fontSize = size.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        color = Color.White.copy(alpha = a), textAlign = TextAlign.Center, maxLines = 2,
        style = TextStyle(shadow = Shadow(Color.Black, Offset(0f, 2f), 10f)),
        modifier = Modifier.padding(vertical = 2.dp)
    )
}

@Composable
fun VizView(modifier: Modifier) {
    var frame by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { n -> Engine.step(); frame = n } } }
    Canvas(modifier) { drawViz(frame / 1_000_000_000f) }
}

// ---------- библиотека ----------

@Composable
fun LibraryScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var job by remember { mutableStateOf<Job?>(null) }
    val list = remember(App.tracks, q) {
        if (q.isBlank()) App.tracks else App.tracks.filter { (it.title + " " + it.artist).contains(q, true) }
    }

    fun startBatch() {
        job = scope.launch(Dispatchers.IO) {
            val todo = App.tracks.filter { it.id !in App.lyricIds }
            var ok = 0
            for ((i, t) in todo.withIndex()) {
                ensureActive()
                status = "Ищу ${i + 1}/${todo.size}: ${t.title}"
                var text = try { Net.lrclib(t) } catch (e: Exception) { null }
                if (text == null && Cfg.aiInBatch && Cfg.apiKey.isNotBlank()) {
                    status = "ИИ слушает ${i + 1}/${todo.size}: ${t.title}"
                    text = try { Net.transcribe(ctx, t) } catch (e: Exception) { null }
                }
                if (text != null) { Lyrics.save(ctx, t.id, text); ok++ }
            }
            status = "Готово: найдено $ok из ${todo.size}"
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("DizzPlayer", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Acc, modifier = Modifier.weight(1f))
            IconButton({ go("settings") }) { Icon(Icons.Default.Settings, null) }
        }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp), singleLine = true, placeholder = { Text("Поиск по трекам") })
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (job?.isActive == true) Button({ job?.cancel(); status = "Остановлено" }) { Text("Стоп") }
            else Button({ startBatch() }) { Text("Найти тексты для всех") }
            Spacer(Modifier.width(8.dp))
            Text(status, fontSize = 12.sp, maxLines = 2, color = Color.Gray)
        }
        if (App.tracks.isEmpty()) Text("Треков не найдено. Дайте доступ к аудио в настройках телефона.", Modifier.padding(16.dp), color = Color.Gray)
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(list, key = { _, t -> t.id }) { i, t ->
                Row(
                    Modifier.fillMaxWidth().clickable { App.play(list, i); go("player") }.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(t.title, maxLines = 1, color = if (App.current?.id == t.id) Acc else Color.White)
                        Text(t.artist.ifBlank { "Неизвестный исполнитель" }, fontSize = 12.sp, color = Color.Gray, maxLines = 1)
                    }
                    if (t.id in App.lyricIds) Text("♪ текст", fontSize = 11.sp, color = Acc)
                }
            }
        }
        App.current?.let { t ->
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF16161F)).clickable { go("player") }.padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(t.title, Modifier.weight(1f), maxLines = 1)
                IconButton({ if (App.playing) Audio.player.pause() else Audio.player.play() }) {
                    Icon(if (App.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                }
            }
        }
    }
}

// ---------- плеер ----------

@Composable
fun PlayerScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val p = Audio.player
    val t = App.current
    val pos by produceState(0L) { while (true) { value = p.currentPosition; delay(50) } }
    val dur = (if (p.duration > 0) p.duration else (t?.durMs ?: 1L)).coerceAtLeast(1L)
    val lines = remember(t?.id, App.rev) { t?.let { Lyrics.load(ctx, it.id) }?.let { Lyrics.parse(it) } ?: emptyList() }
    val synced = lines.isNotEmpty() && lines[0].t >= 0
    val idx = if (synced) idxAt(lines, pos) else -1
    val micOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    Box(Modifier.fillMaxSize()) {
        VizView(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ go("lib") }) { Icon(Icons.Default.ArrowBack, null) }
                Column(Modifier.weight(1f)) {
                    Text(t?.title ?: "", maxLines = 1, fontWeight = FontWeight.Bold)
                    Text(t?.artist ?: "", fontSize = 12.sp, color = Color.LightGray, maxLines = 1)
                }
                IconButton({ Cfg.flashOn = !Cfg.flashOn }) {
                    Icon(Icons.Default.FlashOn, null, tint = if (Cfg.flashOn) Color.Yellow else Color.Gray)
                }
                IconButton({ go("settings") }) { Icon(Icons.Default.Settings, null) }
            }
            Chips(STYLES, Cfg.style) { Cfg.style = it }
            if (!micOk) Text("Для визуализации нужно разрешение «Микрофон» (используется только для анализа звука плеера).", fontSize = 11.sp, color = Color(0xFFFF8A80), modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.weight(1f))
            Column(Modifier.fillMaxWidth().clickable { go("lyrics") }, horizontalAlignment = Alignment.CenterHorizontally) {
                if (lines.isEmpty()) Lt("Текста пока нет — нажмите, чтобы найти или написать", 14, 0.6f)
                else if (!synced) Lt("Текст без меток времени — откройте «Правка» и расставьте метки", 14, 0.7f)
                else Crossfade(idx, label = "lyric") { i ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Lt(lines.getOrNull(i - 1)?.text.orEmpty().ifBlank { " " }, 15, 0.45f)
                        Lt(lines.getOrNull(i)?.text.orEmpty().ifBlank { "♪" }, 24, 1f, true)
                        Lt(lines.getOrNull(i + 1)?.text.orEmpty().ifBlank { " " }, 16, 0.55f)
                    }
                }
            }
            var drag by remember { mutableStateOf<Float?>(null) }
            Slider(
                value = drag ?: (pos.toFloat() / dur).coerceIn(0f, 1f),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { p.seekTo((it * dur).toLong()) }; drag = null }
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                Text(Lyrics.fmt(pos).take(5), fontSize = 12.sp, color = Color.LightGray)
                Spacer(Modifier.weight(1f))
                Text(Lyrics.fmt(dur).take(5), fontSize = 12.sp, color = Color.LightGray)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                TextButton({ go("lyrics") }) { Text("Текст") }
                IconButton({ p.seekToPrevious() }, Modifier.size(56.dp)) { Icon(Icons.Default.SkipPrevious, null, Modifier.size(36.dp)) }
                FilledIconButton({ if (App.playing) p.pause() else p.play() }, Modifier.size(72.dp)) {
                    Icon(if (App.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, Modifier.size(40.dp))
                }
                IconButton({ p.seekToNext() }, Modifier.size(56.dp)) { Icon(Icons.Default.SkipNext, null, Modifier.size(36.dp)) }
                TextButton({ go("edit") }) { Text("Правка") }
            }
        }
    }
}

// ---------- текст песни ----------

@Composable
fun LyricsScreen(go: (String) -> Unit) {
    val t = App.current
    if (t == null) { Text("Сначала выберите трек", Modifier.padding(24.dp)); return }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = Audio.player
    val pos by produceState(0L) { while (true) { value = p.currentPosition; delay(100) } }
    val lines = remember(t.id, App.rev) { Lyrics.load(ctx, t.id)?.let { Lyrics.parse(it) } ?: emptyList() }
    val synced = lines.isNotEmpty() && lines[0].t >= 0
    val idx = if (synced) idxAt(lines, pos) else -1
    val ls = rememberLazyListState()
    LaunchedEffect(idx) { if (idx >= 0) ls.animateScrollToItem((idx - 2).coerceAtLeast(0)) }
    var busy by remember { mutableStateOf("") }
    var ask by remember { mutableStateOf<(() -> Unit)?>(null) }

    fun online() {
        scope.launch {
            busy = "Ищу текст в интернете…"
            val r = withContext(Dispatchers.IO) { runCatching { Net.lrclib(t) }.getOrNull() }
            if (r != null) { Lyrics.save(ctx, t.id, r); busy = "Найдено" } else busy = "Не найдено. Попробуйте ИИ-распознавание."
        }
    }
    fun ai() {
        scope.launch {
            busy = "ИИ слушает песню… (до минуты)"
            val r = withContext(Dispatchers.IO) { runCatching { Net.transcribe(ctx, t) } }
            r.onSuccess { Lyrics.save(ctx, t.id, it); busy = "Готово. Проверьте текст и поправьте в «Править»" }
                .onFailure { busy = "Ошибка: ${it.message}" }
        }
    }
    fun guard(a: () -> Unit) { if (lines.isNotEmpty()) ask = a else a() }

    ask?.let { a ->
        AlertDialog(
            onDismissRequest = { ask = null },
            title = { Text("Заменить текущий текст?") },
            text = { Text("Ваши правки будут потеряны.") },
            confirmButton = { TextButton({ ask = null; a() }) { Text("Заменить") } },
            dismissButton = { TextButton({ ask = null }) { Text("Отмена") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ go("player") }) { Icon(Icons.Default.ArrowBack, null) }
            Text(t.title, maxLines = 1, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ guard { online() } }) { Text("Искать") }
            OutlinedButton({ guard { ai() } }) { Text("ИИ") }
            OutlinedButton({ go("edit") }) { Text("Править") }
        }
        if (busy.isNotEmpty()) Text(busy, fontSize = 12.sp, color = Acc, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        LazyColumn(state = ls, modifier = Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp)) {
            if (lines.isEmpty()) item {
                Text("Текста пока нет.\n«Искать» — бесплатная база онлайн, «ИИ» — распознать голос в песне, «Править» — вставить свой.", color = Color.Gray)
            }
            itemsIndexed(lines) { i, l ->
                val cur = i == idx
                Text(
                    l.text.ifBlank { "♪" }, fontSize = if (cur) 24.sp else 19.sp,
                    fontWeight = if (cur) FontWeight.Bold else FontWeight.Normal,
                    color = if (cur) Acc else Color.White.copy(alpha = if (synced) 0.55f else 0.9f),
                    modifier = Modifier.fillMaxWidth().clickable(enabled = synced) { p.seekTo(l.t) }.padding(vertical = 8.dp)
                )
            }
        }
    }
}

private fun stamp(tf: TextFieldValue, pos: Long): TextFieldValue {
    val text = tf.text
    val s = tf.selection.start.coerceIn(0, text.length)
    val ls = text.lastIndexOf('\n', s - 1) + 1
    var le = text.indexOf('\n', ls)
    if (le < 0) le = text.length
    val line = text.substring(ls, le).replace(Regex("^(\\[\\d+:\\d+([.:]\\d+)?])+"), "")
    val ins = "[${Lyrics.fmt(pos)}]$line"
    val res = text.substring(0, ls) + ins + text.substring(le)
    return TextFieldValue(res, TextRange((ls + ins.length + 1).coerceAtMost(res.length)))
}

@Composable
fun EditScreen(go: (String) -> Unit) {
    val t = App.current
    if (t == null) { Text("Сначала выберите трек", Modifier.padding(24.dp)); return }
    val ctx = LocalContext.current
    val p = Audio.player
    val pos by produceState(0L) { while (true) { value = p.currentPosition; delay(50) } }
    var tf by remember { mutableStateOf(TextFieldValue(Lyrics.load(ctx, t.id) ?: "")) }

    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton({ go("lyrics") }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Правка: ${t.title}", Modifier.weight(1f), maxLines = 1, fontWeight = FontWeight.Bold)
            Button({ Lyrics.save(ctx, t.id, tf.text); go("lyrics") }) { Text("Сохранить") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton({ if (App.playing) p.pause() else p.play() }) {
                Icon(if (App.playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
            }
            Text(Lyrics.fmt(pos), color = Acc)
            Spacer(Modifier.width(12.dp))
            OutlinedButton({ tf = stamp(tf, pos) }) { Text("Вставить время") }
        }
        Text(
            "Формат строки: [мм:сс.хх] слова. Поставьте курсор в строку и нажмите «Вставить время» в момент, когда её поют — курсор перейдёт на следующую строку. Пустой текст = удалить.",
            fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 4.dp)
        )
        OutlinedTextField(tf, { tf = it }, Modifier.weight(1f).fillMaxWidth())
    }
}

// ---------- настройки ----------

@Composable
fun H(s: String) { Text(s, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Acc, modifier = Modifier.padding(top = 20.dp, bottom = 6.dp)) }

@Composable
fun Sl(label: String, v: Float, r: ClosedFloatingPointRange<Float>, shown: String, set: (Float) -> Unit) {
    Text("$label: $shown", fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    Slider(v, set, valueRange = r)
}

@Composable
fun SwitchRow(label: String, v: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(v, set)
    }
}

@Composable
fun SettingsScreen(go: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton({ go("lib") }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Настройки", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        H("Визуализация")
        Chips(STYLES, Cfg.style) { Cfg.style = it }
        Spacer(Modifier.height(8.dp))
        Chips(PALETTES, Cfg.palette) { Cfg.palette = it }
        Sl("Чувствительность", Cfg.gain, 0.5f..2.5f, "${(Cfg.gain * 100).toInt()}%") { Cfg.gain = it }
        SwitchRow("Частицы", Cfg.particles) { Cfg.particles = it }

        H("Вспышка под бит")
        SwitchRow("Включить вспышку", Cfg.flashOn) { Cfg.flashOn = it }
        if (!Flash.available) Text("Вспышка на этом устройстве не найдена", color = Color(0xFFFF6B6B))
        Chips(listOf("Бас", "Середина", "Верха", "Всё"), Cfg.flashBand) { Cfg.flashBand = it }
        Sl("Чувствительность к биту", Cfg.flashSens, 0f..1f, "${(Cfg.flashSens * 100).toInt()}%") { Cfg.flashSens = it }
        Sl("Длина вспышки", Cfg.flashLen, 20f..200f, "${Cfg.flashLen.toInt()} мс") { Cfg.flashLen = it }
        Sl("Мин. пауза между вспышками", Cfg.flashGap, 100f..600f, "${Cfg.flashGap.toInt()} мс") { Cfg.flashGap = it }
        if (Flash.hasStrength) Sl("Яркость", Cfg.flashBright, 0.1f..1f, "${(Cfg.flashBright * 100).toInt()}%") { Cfg.flashBright = it }
        Button({ Flash.pulse() }, Modifier.padding(top = 8.dp)) { Text("Тест вспышки") }
        Text(
            "⚠ Мигающий свет может спровоцировать приступ при фоточувствительной эпилепсии. Частые вспышки нагревают светодиод.",
            fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 6.dp)
        )

        H("ИИ-тексты")
        Chips(listOf("Groq (бесплатно)", "OpenAI"), Cfg.provider) { Cfg.provider = it }
        OutlinedTextField(
            Cfg.apiKey, { Cfg.apiKey = it.trim() }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
            label = { Text("API-ключ") }, visualTransformation = PasswordVisualTransformation()
        )
        OutlinedTextField(
            Cfg.aiLang, { Cfg.aiLang = it.take(5) }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
            label = { Text("Язык песен (ru, en… пусто = авто)") }
        )
        SwitchRow("В массовом поиске: если текста нет в базе — распознавать ИИ", Cfg.aiInBatch) { Cfg.aiInBatch = it }
        Text("Ключ Groq: console.groq.com → API Keys. Файл трека до 25 МБ. Распознавание пения может ошибаться — тексты можно поправить в «Править».", fontSize = 11.sp, color = Color.Gray)
        Spacer(Modifier.height(32.dp))
    }
}
