package com.dizz.player

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.pow
import kotlin.math.sqrt

object Audio {
    lateinit var player: ExoPlayer
    @Volatile var playing = false

    fun init(c: Context) {
        if (::player.isInitialized) return
        val app = c.applicationContext
        Engine.app = app
        player = ExoPlayer.Builder(app)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
                App.playing = isPlaying
                if (isPlaying) Engine.attach(player.audioSessionId)
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                Engine.attach(audioSessionId)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                App.current = App.tracks.firstOrNull { it.id.toString() == mediaItem?.mediaId }
            }
        })
        Engine.attach(player.audioSessionId)
    }
}

private class Beat {
    var ema = 0f; var prev = 0f; var last = 0L
    fun hit(e: Float, thr: Float, gapMs: Long, now: Long): Boolean {
        val ok = e > 0.02f && e > ema * thr && e > prev && now - last >= gapMs
        ema += (e - ema) * 0.07f
        prev = e
        if (ok) last = now
        return ok
    }
}

object Engine {
    const val N = 64
    lateinit var app: Context
    val target = FloatArray(N)
    val shown = FloatArray(N)
    @Volatile var pulse = 0f
    @Volatile var beatCount = 0
    private var vis: Visualizer? = null
    private var sid = -1
    private val vb = Beat()
    private val fb = Beat()

    fun attach(session: Int) {
        if (!::app.isInitialized) return
        if (session == sid && vis != null) return
        release()
        if (session <= 0) return
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            val v = Visualizer(session)
            v.setEnabled(false)
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1])
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) onFft(fft, samplingRate)
                }
            }, Visualizer.getMaxCaptureRate(), false, true)
            v.setEnabled(true)
            vis = v; sid = session
        } catch (e: Exception) {
            vis = null; sid = -1
        }
    }

    private fun release() {
        try { vis?.setEnabled(false); vis?.release() } catch (e: Exception) { }
        vis = null; sid = -1
    }

    private fun onFft(fft: ByteArray, rate: Int) {
        val bins = fft.size / 2
        if (bins < 8) return
        val hz = if (rate > 0) (rate / 1000f) / fft.size else 43f
        val mag = FloatArray(bins)
        for (k in 1 until bins) {
            val re = fft[2 * k].toInt(); val im = fft[2 * k + 1].toInt()
            mag[k] = sqrt((re * re + im * im).toFloat())
        }
        fun at(f: Float): Float {
            val b = f / hz
            val i = b.toInt().coerceIn(1, bins - 2)
            val fr = (b - i).coerceIn(0f, 1f)
            return mag[i] * (1 - fr) + mag[i + 1] * fr
        }
        fun band(f1: Float, f2: Float): Float {
            val a = (f1 / hz).toInt().coerceIn(1, bins - 1)
            val b = (f2 / hz).toInt().coerceIn(a, bins - 1)
            var s = 0f
            for (k in a..b) s += mag[k]
            return s / (b - a + 1)
        }
        for (i in 0 until N) {
            val f1 = 40f * 200f.pow(i / N.toFloat()); val f2 = 40f * 200f.pow((i + 1) / N.toFloat())
            val lo = f1 / hz; val hi = f2 / hz
            val m = if (hi - lo < 1f) at((f1 + f2) / 2) else {
                var mx = 0f
                for (k in lo.toInt().coerceAtLeast(1)..hi.toInt().coerceAtMost(bins - 1)) if (mag[k] > mx) mx = mag[k]
                mx
            }
            target[i] = ((m / 110f).pow(0.65f) * (1f + 1.2f * i / N)).coerceIn(0f, 1.3f)
        }
        val now = System.currentTimeMillis()
        val bass = band(40f, 160f) / 128f
        if (vb.hit(bass, 1.35f, 120L, now)) { pulse = 1f; beatCount++ }
        if (Cfg.flashOn && Audio.playing) {
            val e = when (Cfg.flashBand) {
                0 -> bass
                1 -> band(300f, 2000f) / 128f
                2 -> band(2000f, 10000f) / 128f
                else -> band(40f, 10000f) / 128f
            }
            if (fb.hit(e, 2.0f - 0.85f * Cfg.flashSens, Cfg.flashGap.toLong(), now)) Flash.pulse()
        } else Flash.stop()
    }

    /** Вызывается каждый кадр: плавно подтягивает отображаемые значения к целевым. */
    fun step() {
        val on = Audio.playing
        for (i in 0 until N) {
            val tg = if (on) (target[i] * Cfg.gain).coerceIn(0f, 1.25f) else 0f
            val s = shown[i]
            shown[i] = s + (tg - s) * (if (tg > s) 0.55f else 0.10f)
        }
        pulse *= 0.92f
    }
}

object Flash {
    private var cm: CameraManager? = null
    private var id: String? = null
    private var maxLevel = 1
    private var lit = false
    private val h = Handler(Looper.getMainLooper())
    private val off = Runnable { set(false) }
    val available get() = id != null
    val hasStrength get() = maxLevel > 1

    fun init(c: Context) {
        if (cm != null) return
        try {
            val m = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm = m
            for (cid in m.cameraIdList) {
                val ch = m.getCameraCharacteristics(cid)
                if (ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
                ) {
                    id = cid
                    if (Build.VERSION.SDK_INT >= 33) maxLevel = ch.get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                    break
                }
            }
        } catch (e: Exception) { }
    }

    private fun set(v: Boolean) {
        val m = cm ?: return
        val i = id ?: return
        try {
            if (v && Build.VERSION.SDK_INT >= 33 && maxLevel > 1)
                m.turnOnTorchWithStrengthLevel(i, (1 + (maxLevel - 1) * Cfg.flashBright).toInt().coerceIn(1, maxLevel))
            else m.setTorchMode(i, v)
            lit = v
        } catch (e: Exception) { }
    }

    fun pulse() {
        h.post { set(true); h.removeCallbacks(off); h.postDelayed(off, Cfg.flashLen.toLong()) }
    }

    fun stop() {
        if (lit) h.post { h.removeCallbacks(off); set(false) }
    }
}
