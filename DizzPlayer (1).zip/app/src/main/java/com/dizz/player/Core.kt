package com.dizz.player

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs

data class Track(val id: Long, val title: String, val artist: String, val album: String, val durMs: Long, val ext: String) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    fun item(): MediaItem = MediaItem.Builder().setUri(uri).setMediaId(id.toString())
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist.ifBlank { null }).build())
        .build()
}

data class LrcLine(val t: Long, val text: String)

object App {
    var tracks by mutableStateOf<List<Track>>(emptyList())
    var current by mutableStateOf<Track?>(null)
    var playing by mutableStateOf(false)
    var lyricIds by mutableStateOf<Set<Long>>(emptySet())
    var rev by mutableIntStateOf(0)

    fun refresh(c: Context) {
        tracks = Library.scan(c)
        lyricIds = Lyrics.ids(c)
    }

    fun play(list: List<Track>, i: Int) {
        val p = Audio.player
        p.setMediaItems(list.map { it.item() }, i, 0L)
        p.prepare()
        p.play()
    }
}

fun idxAt(lines: List<LrcLine>, pos: Long): Int {
    var lo = 0; var hi = lines.size - 1; var r = -1
    while (lo <= hi) {
        val m = (lo + hi) / 2
        if (lines[m].t <= pos) { r = m; lo = m + 1 } else hi = m - 1
    }
    return r
}

object Library {
    fun scan(c: Context): List<Track> {
        val out = ArrayList<Track>()
        val proj = arrayOf(Media._ID, Media.TITLE, Media.ARTIST, Media.ALBUM, Media.DURATION, Media.DISPLAY_NAME)
        try {
            c.contentResolver.query(
                Media.EXTERNAL_CONTENT_URI, proj,
                "${Media.IS_MUSIC} != 0 AND ${Media.DURATION} > 20000", null,
                "${Media.TITLE} COLLATE NOCASE ASC"
            )?.use { q ->
                while (q.moveToNext()) {
                    val art = q.getString(2) ?: ""
                    val alb = q.getString(3) ?: ""
                    out.add(
                        Track(
                            q.getLong(0), q.getString(1) ?: "?",
                            if (art.startsWith("<")) "" else art,
                            if (alb.startsWith("<")) "" else alb,
                            q.getLong(4),
                            (q.getString(5) ?: "").substringAfterLast('.', "mp3").lowercase()
                        )
                    )
                }
            }
        } catch (e: Exception) { }
        return out
    }
}

object Lyrics {
    private val tag = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")
    private val meta = Regex("^\\[[a-zA-Z]+:.*]$")

    private fun file(c: Context, id: Long) = File(File(c.filesDir, "lyrics"), "$id.lrc")
    fun load(c: Context, id: Long): String? = file(c, id).let { if (it.exists()) it.readText() else null }

    fun save(c: Context, id: Long, text: String) {
        val f = file(c, id)
        if (text.isBlank()) {
            f.delete(); App.lyricIds = App.lyricIds - id
        } else {
            f.parentFile?.mkdirs(); f.writeText(text); App.lyricIds = App.lyricIds + id
        }
        App.rev++
    }

    fun ids(c: Context): Set<Long> =
        File(c.filesDir, "lyrics").listFiles()?.mapNotNull { it.nameWithoutExtension.toLongOrNull() }?.toSet() ?: emptySet()

    fun fmt(ms: Long): String {
        val m = ms / 60000; val s = (ms / 1000) % 60; val cs = (ms % 1000) / 10
        return String.format(Locale.US, "%02d:%02d.%02d", m, s, cs)
    }

    fun parse(text: String): List<LrcLine> {
        val out = ArrayList<LrcLine>()
        for (raw in text.lines()) {
            val ms = tag.findAll(raw).toList()
            val body = tag.replace(raw, "").trim()
            if (ms.isEmpty()) {
                if (body.isNotEmpty() && !meta.matches(body)) out.add(LrcLine(-1, body))
                continue
            }
            for (m in ms) {
                val t = m.groupValues[1].toLong() * 60000 + m.groupValues[2].toLong() * 1000 +
                    (m.groupValues[3].padEnd(3, '0').toLongOrNull() ?: 0L)
                out.add(LrcLine(t, body))
            }
        }
        return if (out.any { it.t >= 0 }) out.filter { it.t >= 0 }.sortedBy { it.t } else out
    }
}

object Net {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(180, TimeUnit.SECONDS).writeTimeout(180, TimeUnit.SECONDS).build()

    private fun get(url: HttpUrl): String? = try {
        http.newCall(Request.Builder().url(url).header("User-Agent", "DizzPlayer/1.0").build()).execute()
            .use { r -> if (r.isSuccessful) r.body?.string() else null }
    } catch (e: Exception) { null }

    private fun str(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")

    private fun clean(s: String) = s
        .replace(Regex("[\\(\\[].*?[\\)\\]]"), " ")
        .replace(Regex("(?i)\\b(feat|ft)\\.?.*$"), "")
        .replace(Regex("^\\d+[.\\-\\s]+"), "")
        .replace(Regex("\\s+"), " ").trim()

    /** Бесплатная база LRCLIB (с синхронизированными текстами). Возвращает LRC или обычный текст. */
    fun lrclib(t: Track): String? {
        var title = t.title; var artist = t.artist
        if (artist.isBlank() && " - " in title) { artist = title.substringBefore(" - "); title = title.substringAfter(" - ") }
        title = clean(title); artist = clean(artist)
        val sec = t.durMs / 1000
        var plain: String? = null

        val u = "https://lrclib.net/api/get".toHttpUrl().newBuilder()
            .addQueryParameter("track_name", title).addQueryParameter("artist_name", artist)
        if (t.album.isNotBlank()) u.addQueryParameter("album_name", t.album)
        u.addQueryParameter("duration", sec.toString())
        get(u.build())?.let { body ->
            val j = JSONObject(body)
            if (!j.optBoolean("instrumental")) {
                val sy = str(j, "syncedLyrics"); if (sy.isNotBlank()) return sy
                val p = str(j, "plainLyrics"); if (p.isNotBlank()) plain = p
            }
        }

        val s = "https://lrclib.net/api/search".toHttpUrl().newBuilder().addQueryParameter("track_name", title)
        if (artist.isNotBlank()) s.addQueryParameter("artist_name", artist)
        val arr = JSONArray(get(s.build()) ?: return plain)
        var best: JSONObject? = null; var bd = Double.MAX_VALUE
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optBoolean("instrumental")) continue
            if (str(o, "syncedLyrics").isNotBlank()) {
                val d = abs(o.optDouble("duration", 0.0) - sec)
                if (d < bd) { bd = d; best = o }
            } else if (plain == null && str(o, "plainLyrics").isNotBlank()) plain = str(o, "plainLyrics")
        }
        if (best != null && bd <= 10) return str(best, "syncedLyrics")
        return plain
    }

    /** ИИ (Whisper в облаке) слушает трек и возвращает текст с метками времени в формате LRC. */
    fun transcribe(c: Context, t: Track): String {
        val key = Cfg.apiKey.trim()
        if (key.isEmpty()) throw Exception("Укажите API-ключ в настройках")
        val url = if (Cfg.provider == 0) "https://api.groq.com/openai/v1/audio/transcriptions"
        else "https://api.openai.com/v1/audio/transcriptions"
        val model = if (Cfg.provider == 0) "whisper-large-v3" else "whisper-1"
        val tmp = File(c.cacheDir, "ai_${t.id}.${t.ext}")
        try {
            (c.contentResolver.openInputStream(t.uri) ?: throw Exception("Не удалось открыть файл"))
                .use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            if (tmp.length() > 24L * 1024 * 1024) throw Exception("Файл больше 25 МБ — лимит облачного ИИ")
            val b = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("file", "audio.${t.ext}", tmp.asRequestBody("application/octet-stream".toMediaType()))
                .addFormDataPart("model", model)
                .addFormDataPart("response_format", "verbose_json")
                .addFormDataPart("timestamp_granularities[]", "segment")
                .addFormDataPart("temperature", "0")
            if (Cfg.aiLang.isNotBlank()) b.addFormDataPart("language", Cfg.aiLang.trim())
            val req = Request.Builder().url(url).header("Authorization", "Bearer $key").post(b.build()).build()
            val text = http.newCall(req).execute().use { r ->
                val body = r.body?.string() ?: ""
                if (!r.isSuccessful) throw Exception("ИИ: HTTP ${r.code} ${body.take(160)}")
                val segs = JSONObject(body).optJSONArray("segments") ?: throw Exception("ИИ не вернул текст")
                val sb = StringBuilder()
                for (i in 0 until segs.length()) {
                    val s = segs.getJSONObject(i)
                    val tx = s.optString("text").trim()
                    if (tx.isNotEmpty()) sb.append('[').append(Lyrics.fmt((s.optDouble("start") * 1000).toLong())).append(']').append(tx).append('\n')
                }
                if (sb.isEmpty()) throw Exception("Слов в треке не найдено")
                sb.toString().trim()
            }
            return text
        } finally {
            tmp.delete()
        }
    }
}
